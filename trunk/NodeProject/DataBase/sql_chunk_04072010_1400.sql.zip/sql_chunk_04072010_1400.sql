-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Jul 04, 2010 as 02:09 PM
-- Versão do Servidor: 5.0.45
-- Versão do PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `filecontrol`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `chunk`
-- 

CREATE TABLE `chunk` (
  `fileID` bigint(255) NOT NULL,
  `id` bigint(255) NOT NULL,
  `stream` longblob NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Extraindo dados da tabela `chunk`
-- 

INSERT INTO `chunk` (`fileID`, `id`, `stream`) VALUES 
(0, 1, 0x6a6176612e696f2e46696c65496e70757453747265616d40633434623838);
