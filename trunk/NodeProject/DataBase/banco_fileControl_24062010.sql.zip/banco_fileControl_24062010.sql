-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Jun 24, 2010 as 02:11 PM
-- Versão do Servidor: 5.0.45
-- Versão do PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `filecontrol`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `chunk`
-- 

CREATE TABLE `chunk` (
  `id` bigint(255) NOT NULL,
  `sequencia` bigint(255) NOT NULL auto_increment,
  `stream` longblob NOT NULL,
  PRIMARY KEY  (`sequencia`),
  UNIQUE KEY `sequencia` (`sequencia`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Extraindo dados da tabela `chunk`
-- 

