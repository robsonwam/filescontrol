-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Geração: Jun 27, 2010 as 07:37 PM
-- Versão do Servidor: 5.0.45
-- Versão do PHP: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Banco de Dados: `filecontrol`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `chunk`
-- 

CREATE TABLE `chunk` (
  `id` bigint(255) NOT NULL,
  `fileID` bigint(255) NOT NULL,
  `stream` longblob NOT NULL,
  PRIMARY KEY  (`id`,`fileID`),
  UNIQUE KEY `sequencia` (`fileID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Extraindo dados da tabela `chunk`
-- 

